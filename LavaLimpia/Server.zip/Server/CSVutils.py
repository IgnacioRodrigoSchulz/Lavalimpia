def convertirMatrizaCSV(matriz):
    csvf = ""
    for row in matriz:
        fila = ""
        for i in row:
            fila += str(i)+ ','
        csvf += fila + '\n'
    return csvf

