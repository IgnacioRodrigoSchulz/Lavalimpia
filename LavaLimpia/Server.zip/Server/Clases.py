#User
import uuid


class User():
    def __init__(self, username, password):
        self.UUID = uuid.uuid1()
        self.username = username
        self.password = password

    def loginCheck(passInput):
        if self.password == passInput:
            return True
        else:
            return False

class Pedido():
    def __init__(self):
        self.UUID = uuid.uuid1()
        pass

class DataBase():
    def __init__(self, filename):
        self.filename = filename
        pass
