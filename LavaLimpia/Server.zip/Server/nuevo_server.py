import socket
import threading
from Clases import User
from Login import login
from CreateUser import AddUser
from commandProtocol import commandEncoder
from commandProtocol import commandDecoder
from time import sleep

# get the hostname
host = '0.0.0.0'
port = 5000  # initiate port no above 1024

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  #crear instancia
server.bind((host, port))  # Vincular dirección y puerto

server.listen()

clients = []

def handle(client):
    while True:
        try:        #Ciclo de comunicación
            message = client.recv(1024).decode('UTF-8')
#            client.send("Connected to server".encode('UTF-8'))
            arguments = commandDecoder(message)
            command = arguments.pop(0)
            print(command)
            print(arguments)
            if command == "exit":
                client.send("exit".encode('UTF-8'))
                clients.remove(client)
                client.close()
                print("Client disconnected")
                break

            match command:
                case "add":
                    newUser = User(arguments[0], arguments[1])
                    print(newUser)
                    AddUser(newUser)
                    command = ["print", "Usuario creado"]
                    message = commandEncoder(command)
                    client.send(message.encode('UTF-8'))
                    sleep(0.5)
                case "login":
                    if login(arguments[0], arguments[1]):
                        result = "True"
                    else:
                        result = "False"
                    command = ["print", result]
                    message = commandEncoder(command)
                    client.send(message.encode('UTF-8'))
                    sleep(0.5)


            
        except:     #Excepcion/fallo de comunicación
            clients.remove(client)
            client.close()
            print("Error, an exemption occurred")
            break


def receive():
    while True:
        client, address = server.accept()
        print(f"Client connected from "+ str(address))

#        client.send('Connection established'.encode('UTF-8'))
        clients.append(client)

        thread = thread = threading.Thread(target=handle, args=(client,))
        thread.start()


print("Server is listening...")
receive()

