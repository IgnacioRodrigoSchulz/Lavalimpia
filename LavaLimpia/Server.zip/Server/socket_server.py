import socket

from Clases import User
from Login import login
from CreateUser import AddUser

def server_program():
    # get the hostname
    host = '192.168.146.89'
    port = 5000  # initiate port no above 1024

    server_socket = socket.socket()  # get instance
    # look closely. The bind() function takes tuple as argument
    server_socket.bind((host, port))  # bind host address and port together

    # configure how many client the server can listen simultaneously
    server_socket.listen(2)
    conn, address = server_socket.accept()  # accept new connection
    print("Connection from: " + str(address))
    
    #Ciclo principal
    while True:
        # receive data stream. it won't accept data packet greater than 1024 bytes
        entry = conn.recv(1024).decode()
        if not entry:
            # if data is not received break
            break
        #print("from connected user: " + str(entry))
        #data = input(' -> ')
        if entry == "exit":
            break
        else:
            command = entry.split()
            match command[0]:
                case "add":
                    newUser = User(command[1], command[2])
                    AddUser(newUser)
                    data = "Usuario añadido."
                case "login":
                    if login(command[1], command[2]):
                        data = "Sesión iniciada"
                    else:
                        data = "Nombre de usuario o contraseña incorrecta."               

                case _:
                        data = "Error: comando inexistente."
        conn.send(data.encode())  # send data to the client

    conn.close()  # close the connection


if __name__ == '__main__':
    server_program()
