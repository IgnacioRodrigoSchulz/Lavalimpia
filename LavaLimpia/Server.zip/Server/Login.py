#CrearUsuario

from Clases import User
from Reader import findUser

filename = "usuarios.csv"

def login(username, password):
    target = findUser(username)
    if target.username == "null":
        return False
    if target.password == password:
        return True
    else:
        return False





    
