#https://stackoverflow.com/questions/4529815/saving-an-object-data-persistence

import pickle
import uuid

class Company(object):
    def __init__(self, name, value):
        self.ID = uuid.uuid4()
        self.name = name
        self.value = value

with open('company_data.pkl', 'wb') as outp:
    company1 = Company('banana', 40)
    print(company1.ID)
    pickle.dump(company1, outp, pickle.HIGHEST_PROTOCOL)

    company2 = Company('spam', 42)
    print(company2.ID)
    pickle.dump(company2, outp, pickle.HIGHEST_PROTOCOL)

del company1
del company2

with open('company_data.pkl', 'rb') as inp:
    company1 = pickle.load(inp)
    print(company1.name)  # -> banana
    print(company1.ID)  # -> 40

    company2 = pickle.load(inp)
    print(company2.name) # -> spam
    print(company2.ID)  # -> 42

