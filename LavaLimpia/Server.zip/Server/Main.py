#Programa principal
from Clases import User
from Login import login
from CreateUser import AddUser

filename = "usuarios.csv"

#Loop principal


def receiver():
    while True:
        entry = input("C: ")
        if entry == "exit":
            break
        else:
            command = entry.split()
            match command[0]:
                case "add":
                    newUser = User(command[1], command[2])
                    AddUser(newUser)
                    print("Usuario añadido.")
                case "login":
                    if login(command[1], command[2]):
                        print("Sesión iniciada")
                    else:
                        print("Nombre de usuario o contraseña incorrecta.")                

                case _:
                    print("Error: comando inexistente.")


receiver()
