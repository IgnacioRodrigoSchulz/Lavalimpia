#CrearUsuario

from Clases import User

filename = "usuarios.csv"

def addRow(CSVfilename, row):
    rowStr = ""
    for i in range(len(row)-1):
        rowStr += str(row[i]) + ','
    rowStr += row[len(row)-1]
    rowStr += '\n'
    with open(CSVfilename, "a") as archivo:
        archivo.write(rowStr)

def AddUser(user):
    addRow(filename, [user.username, user.password])



    
