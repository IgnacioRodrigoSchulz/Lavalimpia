#Lector de Datos

filename = "usuarios.csv"

from Clases import User

def loadMatrix(CSVfilename):
    with open(CSVfilename, "r") as archivo:
        CSV = archivo.readlines()
    matrix = []
    for line in CSV:
        line = line.replace('\n', '')
        #print(line)
        matrix.append(line.rsplit(','))
        
    return matrix

def matrixtoUserlist(matrix):
    userList = []
    for row in matrix:
        userList.append(User(row[0], row[1]))

    return userList

def loadUsersData():
    return matrixtoUserlist(loadMatrix(filename))

def findUser(targetUsername):
    userList = loadUsersData()
    for user in userList:
        if user.username == targetUsername:
            return user
    return User("null", "null")
    
    
        

